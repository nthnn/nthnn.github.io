package xyz.nathannestein.nilboard;

import android.inputmethodservice.InputMethodService;

public class Nilboard extends InputMethodService {
    public boolean onEvaluateInputViewShown() {
        return false;
    }
    
    public boolean onShowInputRequested(int n, boolean bl) {
        return false;
    }
    
    public void onWindowShown() { }
} 